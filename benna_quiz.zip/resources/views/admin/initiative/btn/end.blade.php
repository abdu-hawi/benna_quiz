<a href="{!! url('initiatives/'.$id) !!}" class="btn btn-outline-success btn-sm">
    <i class="fas fa-gem"></i>
</a>
