<a href="{!! url('initiatives/'.$id.'/qrCode') !!}" class="btn btn-outline-primary btn-sm" target="_blank">
    <i class="fa fa-print"></i>
</a>
