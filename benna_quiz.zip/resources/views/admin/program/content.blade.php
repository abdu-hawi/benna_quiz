@push('css')
{{--    <link rel="stylesheet" href="{!! url('/') !!}/design/plugins/datatables-bs4/css/dataTables.bootstrap4.css">--}}
    <link rel="stylesheet" href="{!! asset('design/plugins/datatables-bs4/css/dataTables.bootstrap4.css') !!}">
@endpush
{{--<div class="col-lg-12">--}}

{{--    <div class="row">--}}
{{--        --}}
{{--    </div>--}}
{{--    <!-- /.row -->--}}

{{--</div>--}}

