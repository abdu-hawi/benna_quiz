<a href="{!! url('programs/'.$id.'/edit') !!}" class="btn btn-outline-primary btn-sm">
    <i class="fa fa-edit"></i>
</a>
