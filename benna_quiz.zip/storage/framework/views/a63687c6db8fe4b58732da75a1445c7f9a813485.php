<?php if(session()->has('error')): ?>
    <div class="alert alert-danger text-center card-body col-8" style="margin-left: auto;margin-right: auto;">
        <span><?php echo session('error'); ?></span>
    </div>
<?php endif; ?>

<?php if(session()->has('success')): ?>
    <div class="alert alert-success text-center card-body col-8" style="margin-left: auto;margin-right: auto;">
        <span><?php echo session('success'); ?></span>
    </div>
<?php endif; ?>

<?php if($errors->any()): ?>
    <div class="alert alert-danger card-body col-8" style="margin-left: auto;margin-right: auto;">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<?php /**PATH D:\laravel\benna_quiz\resources\views/admin/layouts/massages.blade.php ENDPATH**/ ?>