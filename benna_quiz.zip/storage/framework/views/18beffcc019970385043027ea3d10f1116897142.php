<?php $__env->startSection('content'); ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0 text-dark">اختيار الفائزين</h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <div class="content">
            <div class="container-fluid">
                <div class="row">

                    <div class="col-lg-12">
                        <style>
                            .small-box .icon > i {
                                left: 15px;
                                right: auto;
                            }
                            .small-box .icon>i.fa{
                                top: 40px;
                            }
                        </style>
                        <div class="row">
                            <?php
                                $bg = ['info','success','warning','gradient-dark'];
                            ?>
                            <?php $__currentLoopData = $quiz; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-3 col-6">
                                    <!-- small card -->
                                    <div class="small-box bg-<?php echo e($bg[$i-1 ?? 0]); ?>">
                                        <div class="small-box-footer">
                                            الإسبوع <?php echo e($i); ?>

                                        </div>
                                        <div class="inner">
                                            <p><?php echo e($q["box_title"]); ?></p>
                                            <h4><?php echo e($q["box_subtitle"]); ?></h4>
                                        </div>
                                        <div class="icon">
                                            <i class="fa fa-users"></i>
                                        </div>
                                        <a class="small-box-footer" <?php echo $q["url"] ? 'style="cursor: pointer" onclick="getPlayer('.$i.')"' : ''; ?>

                                                    <?php echo $q["win"] ? 'style="cursor: pointer" onclick="getWinner('.$i.')"' : ''; ?>>
                                            <?php echo e($q["txt_show_player"]); ?>

                                            <?php echo $q["url"] || $q["win"] ? '<i class="fas fa-arrow-circle-left"></i>':''; ?>

                                        </a>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <!-- ./col -->
                        </div>
                        <!-- /.row -->

                    </div>

                </div>
                <div class="row" id="table-user">
                    <div class="col-lg-12">
                        <center class="m-2 mb-4">
                            <h3>الاسبوع <span id="week-span">1</span></h3>
                        </center>
                        <table class="table">




















                        </table>
                    </div>
                </div>
                <!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
    <?php $__env->startPush('scripts'); ?>

        <script>
            var t = $('#table-user')
            t.hide()
            function getPlayer(week){
                t.hide()
                t.find('thead').remove()
                t.find('tbody').remove()
                $("#week-span").html(week)
                $.ajax({
                    url:'<?php echo route("home.ajax"); ?>',
                    type:'get',
                    data_type:'json',
                    data: {_token:'<?php echo csrf_token(); ?>', week_number: week, isWinner: 'isWinner'},
                    success:function (data) {
                        var txt = '<thead><tr><th scope="col">#</th><th scope="col">الاسم</th><th scope="col">رقم الهوية</th></tr></thead><tbody>'
                        for (let i = 0; i < data.length; i++){
                            txt += '<tr><th scope="row">'+(i+1)+'</th><td>'+data[i].name+'</td><td>'+data[i].national_id+'</td></tr>'
                        }
                        txt += '</tbody>'
                        $('.table').append(txt)
                        t.show()
                    },
                    error:function (){
                        alert("لم يتم الارسال نرجوا المحاولة مرة أخرى")
                    }
                })
                return false
            }
            function getWinner(week){
                t.hide()
                t.find('thead').remove()
                t.find('tbody').remove()
                $("#week-span").html(week);
                getData(week, null)
            }

            function getData(week, isWinner){
                $.ajax({
                    url:'<?php echo route("home.ajax"); ?>',
                    type:'get',
                    data_type:'json',
                    data: {_token:'<?php echo csrf_token(); ?>', week_number: week, isWinner: isWinner},
                    success:function (data) {
                        console.log(data)
                        var txt = '<thead><tr><th scope="col">#</th><th scope="col">الاسم</th><th scope="col">رقم الهوية</th><th scope="col" class="text-center">عدد الأجوبة الصحيحة</th></tr></thead><tbody>'
                        for (let i = 0; i < data.length; i++){
                            txt += '<tr><th scope="row">'+(i+1)+'</th><td>'+data[i].name+'</td><td>'+data[i].national_id+'</td><td class="text-center">'+data[i].correct+
                                '</td></tr>'
                        }
                        txt += '</tbody>'
                        $('.table').append(txt)
                        t.show()
                    },
                    error:function (){
                        alert("لم يتم الارسال نرجوا المحاولة مرة أخرى")
                    }
                })
                return false
            }
        </script>

    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\benna_quiz\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>