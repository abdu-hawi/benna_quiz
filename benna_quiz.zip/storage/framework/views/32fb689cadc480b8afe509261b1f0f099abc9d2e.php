
<!-- Navbar -->
<nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
        <li class="nav-item">
            <a class="nav-link" data-widget="pushmenu" href="#"><i class="fas fa-bars"></i></a>
        </li>



    </ul>

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
        <li>
            <form method="POST" action="<?php echo e(route('logout')); ?>">
                <?php echo csrf_field(); ?>

                <a href="<?php echo e(route('logout')); ?>"
                                     onclick="event.preventDefault();
                                                            this.closest('form').submit();">
                    <i class="fas fa-sign-out-alt"></i>
                </a>
            </form>
        </li>
    </ul>
</nav>
<!-- /.navbar -->
<?php /**PATH D:\laravel\benna_quiz\resources\views/admin/layouts/nav.blade.php ENDPATH**/ ?>