
<!-- Control Sidebar -->
<aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
    <div class="p-3">
        <h5>Title</h5>
        <p>Sidebar content</p>
    </div>
</aside>
<!-- /.control-sidebar -->
<?php /**PATH D:\laravel\benna_quiz\resources\views/admin/layouts/sidebarControl.blade.php ENDPATH**/ ?>