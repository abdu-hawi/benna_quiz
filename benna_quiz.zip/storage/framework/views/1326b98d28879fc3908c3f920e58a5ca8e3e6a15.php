<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="<?php echo asset('design/plugins/datatables-bs4/css/dataTables.bootstrap4.css'); ?>">
<?php $__env->stopPush(); ?>



<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="row">
                <div class="col-12">

                    <?php echo $__env->make('admin.layouts.massages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title"><?php echo $title; ?></h3>
                        </div>
                        <!-- /.card-header -->
                        <form action="<?php echo e(route('questions.post')); ?>" method="POST" >
                            <?php echo csrf_field(); ?>
                            <div class="card-body">

                                <?php
                                    $bg = [[],['secondary', 'white'],['light', 'dark'],['gray', 'white'],['dark', 'white'],];
                                    $week = 0;
                                    $question = 0;
                                ?>
                                <?php for($w=1; $w<5; $w++): ?>
                                    <input type="hidden" name="week_number[<?php echo e($w); ?>]" value="<?php echo e($w); ?>">
                                    <div id="accordion<?php echo e($w); ?>">
                                        <div class="card">
                                            <div class="card-header  bg-<?php echo e($bg[$w][0]); ?>" id="heading<?php echo e($w); ?>">
                                                <h5 class="mb-0">
                                                    <button class="btn btn-link text-<?php echo e($bg[$w][1]); ?>" data-toggle="collapse" data-target="#collapse<?php echo e($w); ?>" aria-expanded="<?php echo e($w == 1 ? 'true' : 'false'); ?>" aria-controls="collapse<?php echo e($w); ?>">
                                                        أسئلة الإسبوع <?php echo e($w); ?>

                                                    </button>
                                                </h5>
                                            </div>
                                            <div id="collapse<?php echo e($w); ?>" class="collapse show" aria-labelledby="heading<?php echo e($w); ?>" data-parent="#accordion<?php echo e($w); ?>">
                                                <div class="card-body">
                                                    <?php for($q=1;$q<8;$q++): ?>
                                                        <label class="col-12">
                                                            السؤال <?php echo e($q); ?> | الإسبوع <?php echo e($w); ?>

                                                            <input type="text" name="question[<?php echo e($w); ?>][<?php echo e($q); ?>]" value="<?php echo e(count($questions) > 0 ? $questions[$question]->question : ''); ?>" class="form-control" required>
                                                        </label>
                                                        جواب السؤال <?php echo e($q); ?>

                                                        <?php for($i = 1 ; $i<5; $i++): ?>
                                                            <div class="form-check mt-1">
                                                                <label class="form-check-label col-10">
                                                                    <input class="form-check-input" type="radio" value="<?php echo e($i); ?>"
                                                                           name="correct[<?php echo e($w); ?>][<?php echo e($q); ?>]" required <?php echo e(count($questions) > 0 ? ($questions[$question]->correct_answer == $questions[$question]->answers[$i-1]->id ?'checked' : '') : ''); ?>>
                                                                    <input type="text" value="<?php echo e($questions[$question]->answers[$i-1]->answer); ?>" name="answer[<?php echo e($w); ?>][<?php echo e($q); ?>][<?php echo e($i); ?>]" class="form-control">
                                                                </label>
                                                            </div>
                                                        <?php endfor; ?>
                                                        <?php $question++;?>
                                                    <?php endfor; ?>
                                                    <label class="mt-3">
                                                        تاريخ نشر أسئلة <?php echo e($w); ?>:
                                                        <input type="date" name="date[<?php echo e($w); ?>]" value="<?php echo e($questions[$question-1]->publish_date); ?>"
                                                               class="form-control" required>
                                                    </label>
                                                </div>
                                            </div>
                                        </div>

                                        <?php $week++;?>

                                    </div>
                                <?php endfor; ?>
                            </div>
                            <!-- /.card-body -->
                            <div class="card-footer">
                                <button type="submit" class="btn btn-success btn-send">حفظ</button>
                            </div>
                        </form>
                    </div>
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->


    <?php $__env->startPush('scripts'); ?>


    <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\benna_quiz\resources\views/admin/questions/edit.blade.php ENDPATH**/ ?>